package Capstone_Project;

import java.util.HashMap;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;

public class StepDefinationFile{
	@Given("User Enters Medicare base URI and Base Path")
	public void user_enters_medicare_base_uri_and_base_path() {
		 RestAssured.given()
		.baseUri("http://localhost:9010")
		.basePath("/get-products")
		.when().get()
		.then().statusCode(200)
		.log().all();
	}
	
	@When("User Executes Get Request Of HTTP method")
	public void user_executes_get_request_of_http_method() {
		RestAssured.given()
		.baseUri("http://localhost:9010")
		.basePath("/get-products")
		.when().get()
		.then().statusCode(200)
		.log().all();
	}
	
	@Then("Validate The Response Status Code")
	public void Validate_the_Response_status_code() {
		RestAssured.given()
		.baseUri("http://localhost:9010")
		.basePath("/get-products")
		.when().get()
		.then().statusCode(200)
		.log().all();
	   
	}
	
	@When("User Executes Post Request Of HTTP method")
	public void user_executes_post_request_of_http_method() {
HashMap<String, String> map = new HashMap<String, String>();
		
		map.put("id", "999");
		map.put("image", ".png");
		map.put("name", "Disprin");
		map.put("category", "medicine");
		map.put("brand", "BZ Medico");
		map.put("status", "1");
		map.put("price", "100");
		
		RestAssured.given()
		.baseUri("http://localhost:9010")
		.basePath("/add-product")
		.contentType("application/json")
		.body(map)
		.when().post()
		.then().statusCode(200).log().all();
	}
	
	@When("User Executes Put Request Of HTTP method")
	public void user_executes_put_request_of_http_method() {
HashMap<String, String> map = new HashMap<String, String>();
		
		map.put("id", "999");
		map.put("image", "2.png");
		map.put("name", "Disprin+");
		map.put("category", "medicine");
		map.put("brand", "BZ Medico");
		map.put("status", "1");
		map.put("price", "120");
		
		RestAssured.given()
		.baseUri("http://localhost:9010")
		.basePath("/update-product")
		.contentType("application/json")
		.body(map)
		.when().put()
		.then().statusCode(200).log().all();
	}
	
	@When("User Executes Put Request Of HTTP method To Update Status Code")
	public void user_executes_put_request_of_http_method_to_update_status_code() {
HashMap<String, String> map = new HashMap<String, String>();
		
		map.put("id", "999");
		map.put("image", "2.png");
		map.put("name", "Disprin+");
		map.put("category", "medicine");
		map.put("brand", "BZ Medico");
		map.put("status", "0");
		map.put("price", "120");
		
		RestAssured.given()
		.baseUri("http://localhost:9010")
		.basePath("/update-product-status")
		.contentType("application/json")
		.body(map)
		.when().put()
		.then().statusCode(200).log().all();
	}

	
	@When("User Executes Delete Request Of HTTP method")
	public void user_executes_delete_request_of_http_method() {
		
		RestAssured.given()
		.baseUri("http://localhost:9010")
		.basePath("/delete-product")
		.queryParam("id", "101")
		.when().delete()
		.then().statusCode(200)
		.log().all();
	}
	}